import DashboardDemo from "../dashboard-demo";

export default function DashboardPage() {
  return <DashboardDemo />;
}